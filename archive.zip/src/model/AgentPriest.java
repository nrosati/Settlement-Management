package model;
public class AgentPriest {

}
