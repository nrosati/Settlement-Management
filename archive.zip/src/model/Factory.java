package model;

public abstract class Factory {

	public Factory() {
		// TODO Auto-generated constructor stub
	}
	
	public abstract Building buildBuilding(String kindOfBuilding);

}
