package model;
public class AgentWarrior extends Agent {
	public AgentWarrior(String name, int locationX, int locationY/*, Image image*/) {
		super(name, locationX, locationY);
		capacity = 20;
	}
}
