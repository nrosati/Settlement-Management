package model;
public class ResourcesWood {

}
