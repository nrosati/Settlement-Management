package model;
public class ResourcesFood extends Resources{
	public ResourcesFood(String name, int locationX, int locationY, boolean dense/*, Image image*/){
		super(name, locationX, locationY, dense);
	}

}
