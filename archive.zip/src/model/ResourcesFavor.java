package model;
public class ResourcesFavor {

}
