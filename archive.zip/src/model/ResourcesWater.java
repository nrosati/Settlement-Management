package model;
public class ResourcesWater extends Resources{
	public ResourcesWater(String name, int locationX, int locationY, boolean dense/*,Image image*/) {
		super(name, locationX, locationY, dense);
	}
}
